/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectdata2;

/**
 *
 * @author Aishah Latif
 */
public class Node
    {
    	private StudentBook data; // entry in bag
        private Node previous;
    	private Node next; // link to next node
    	

    	public Node(StudentBook sb)
    	{
            data = sb;
            next = null;
            previous = null;
    	} 

	public Node getPrevious(){
            return previous;
        }
        
        public void setPrevious(Node previous){
            this.previous = previous;
        }
    	public StudentBook getData()
    	{
            return data;
    	} // end getData


    	public void setData(StudentBook newData)
    	{
            this.data = newData;
    	} // end setData


    	public Node getNext()
    	{
     	   return next;
    	} // end getNextNode


    	public void setNext(Node next)
    	{
            this.next = next;
    	} // end setNextNode
        
        
            @Override
	public String toString(){
		return data.toString();
	}
    } // end Node

