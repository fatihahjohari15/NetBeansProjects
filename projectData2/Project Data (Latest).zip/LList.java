package projectdata2;

public class LList {
	
	private Node head = null;
	public static final int START = 0;
	
	public LList(Node h){
		add(h);
	}
	public LList(){
		head = null;
	}
	public void add(StudentBook sb){
		this.add(new Node(sb));
	}
	public void add(Node sb){
		
		if (isEmpty()){
			setHeadNode(sb);
			return;
		}
		
		Node currentNode = head;
		while(currentNode.getNext() != null){
			currentNode = currentNode.getNext();
		}
		sb.setPrevious(currentNode);
		currentNode.setNext(sb);
	}
	public Node remove(int index){
		if(index == -1){
			return null;
		}
		else if(index == 0){
			Node oldHead = head;
			head = head.getNext();
			return oldHead;
		}
		Node currentNode = getNode(index);
		getNode(index-1).setNext(getNode(index+1));
		getNode(index+1).setPrevious(getNode(index-1));
		currentNode.setNext(null);
		currentNode.setPrevious(null);
		return currentNode;
	}
	public Node remove(StudentBook sb){
		int target = find(sb);
		return remove(target);
	}
	public Node removeByMatric(String ID){
		int target = find(ID);
		return remove(target);
	}
	
	public int find(StudentBook sb){
		Node currentNode = head;
		for (int i = 0; currentNode.getNext() != null; currentNode = currentNode.getNext()){
			if(sb.equals(currentNode)){
				return i;
			}
			currentNode = currentNode.getNext();
			i++;
		}
		return -1;
	}
	public int find(String name){
		Node currentNode = head;
		String studentName = currentNode.getData().getId();
		for (int i = 0; currentNode.getNext() != null; currentNode = currentNode.getNext()){
			if(name == studentName){
				return ++i;
			}
			currentNode = currentNode.getNext();
			studentName = currentNode.getData().getId();
			i++;
		}
		return -1;
	}
	private boolean isEmpty() {
		return (head == null);
	}
	private void setHeadNode(Node sb) {
		head = sb;
	}
	public void insertAt(StudentBook sb, int index){
		this.insertAt(new Node(sb), index);
	}
	
	public void insertAt(Node sb, int index){
		if (index == 0){
			sb.setNext(head);
			head.setPrevious(sb);
			head = sb;
			return;
		}
		else if(isValid(index)){
			int i = 0;
			Node currentNode = head;
			while(i < index-1){
				i++;
				if (currentNode.getNext() != null)
					currentNode = currentNode.getNext();
				else
					break;
			}
			
			sb.setNext(currentNode.getNext());
			currentNode.getNext().setPrevious(sb);
			sb.setPrevious(currentNode);
			currentNode.setNext(sb);
			
			return;
		}
		else if (index == length()){
			add(sb);
			return;
		}
	}
	private Node getHead() {
		return head;
	}
	public boolean isValid(int index) {
		return ((index < length()) && (index >= 0));
	}
	public int length(){
		if(isEmpty()){
			return 0;
		}
		int length;
		Node currentNode = head;
		for (length = 1; currentNode.getNext() != null; currentNode = currentNode.getNext())
			length++;
		return length;
	}
	public Node getNode(int index){
		
		int i = 0;
		Node currentNode = head;
		
		while(currentNode.getNext() != null && i < index){
			currentNode = currentNode.getNext();
			i++;
		}
		
		return currentNode;
	}
	
        @Override
	public String toString(){
		String s = "";
		Node current = head;
		s += current;
		try{
			while (current.getNext() != null){
				s += "\n";
				current = current.getNext();
				s += current;
			}
		}
		catch (NullPointerException e){
			return "List is Empty";
		}
		s += "\n";
		return s;
	}
	
}